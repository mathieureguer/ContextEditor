# ConTextEditor

Documentation in progress (sorry)