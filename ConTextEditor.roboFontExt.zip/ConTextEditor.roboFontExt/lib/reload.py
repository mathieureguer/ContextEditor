import importlib

import context
importlib.reload(context)

import contextSettings
importlib.reload(contextSettings)