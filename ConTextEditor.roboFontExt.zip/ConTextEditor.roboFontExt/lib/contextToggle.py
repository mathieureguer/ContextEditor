from context import ContextDisplaySubscriber, toggleSubscriberClass
from mojo.subscriber import *


toggleSubscriberClass(ContextDisplaySubscriber, registerGlyphEditorSubscriber)

